# Hotan synoptic setting from the ERA5 daily-mean geopotential fields

Point: the rainfall centre of the 19-21 June 2026 event, 81.92 deg E / 36.85 deg N; nearest 0.25 deg grid point **82.0E / 37.0N**, the same point used by the source READMEs of the level folders.

Levels: 500, 600, 650 and 700 hPa, ERA5 daily means for June 2026. Geopotential height in dam (z / 9.80665 / 10). Wind direction is given both as the vector direction (toward) and as the meteorological wind direction (from).

## 1. Geopotential height and temperature, 17-22 June 2026

| day | Z500 | Z600 | Z650 | Z700 | T500 | T600 | T650 | T700 |
| --- | --- | --- | --- | --- | --- | --- | --- | --- |
| 2026-06-17 | 585.0 | 440.4 | 375.1 | 313.4 | 266.0 | 274.9 | 280.5 | 286.1 |
| 2026-06-18 | 582.8 | 437.8 | 372.7 | 311.4 | 267.2 | 274.6 | 278.8 | 283.4 |
| 2026-06-19 | 582.9 | 437.7 | 372.5 | 311.5 | 267.4 | 275.0 | 278.5 | 281.7 |
| 2026-06-20 | 581.7 | 436.9 | 372.0 | 311.2 | 266.9 | 273.9 | 277.6 | 280.8 |
| 2026-06-21 | 580.1 | 435.8 | 371.1 | 310.4 | 265.8 | 273.1 | 276.9 | 280.7 |
| 2026-06-22 | 579.7 | 435.4 | 370.6 | 309.7 | 265.7 | 273.8 | 277.8 | 281.7 |

## 2. Wind at the point: direction the air comes from

| day | 500 hPa | 600 hPa | 650 hPa | 700 hPa |
| --- | --- | --- | --- | --- |
| 2026-06-17 | SE (128 deg, 3.7 m/s) | ENE (67 deg, 5.6 m/s) | NE (55 deg, 4.7 m/s) | NE (45 deg, 3.0 m/s) |
| 2026-06-18 | SSE (153 deg, 3.3 m/s) | ESE (104 deg, 7.0 m/s) | ENE (76 deg, 5.3 m/s) | NE (55 deg, 2.4 m/s) |
| 2026-06-19 | SW (228 deg, 2.3 m/s) | E (101 deg, 1.5 m/s) | E (82 deg, 2.0 m/s) | ENE (75 deg, 2.7 m/s) |
| 2026-06-20 | SSE (160 deg, 3.5 m/s) | E (99 deg, 5.3 m/s) | E (87 deg, 4.8 m/s) | E (85 deg, 3.2 m/s) |
| 2026-06-21 | WSW (254 deg, 4.5 m/s) | WSW (244 deg, 5.5 m/s) | WSW (244 deg, 5.2 m/s) | WSW (247 deg, 4.6 m/s) |
| 2026-06-22 | W (268 deg, 6.8 m/s) | W (267 deg, 8.3 m/s) | W (266 deg, 8.5 m/s) | W (265 deg, 7.8 m/s) |

The vector points the other way, so read the table as the direction the air comes from. Note how different the four levels are on the two event days: on 19-20 June the 600-700 hPa air comes from the east while the 500 hPa air comes from the south-west, and only on 21-22 June do all four levels turn to south-west and then west. The easterly low-to-mid-level flow of 19-20 June is therefore the setting for the convergence against the Kunlun front, and it is strongest at 600 hPa.

## 2b. The same days in the 0.25 deg ERA5 fields of the flux study

Layer-mean wind at the rainfall-centre cell (0.25 deg grid, ERA5 pressure-level daily means) and averaged over a 1.5 x 1.5 deg box around it, to show how much the single grid point and its surroundings differ:

| day | 850 hPa cell | 700-600 hPa cell | 700-600 hPa box | 850-600 hPa box |
| --- | --- | --- | --- | --- |
| 18 Jun | from WSW 248 deg (2.0 m/s) | from E 86 deg (4.6 m/s) | from E 90 deg (3.4 m/s) | from NE 56 deg (1.0 m/s) |
| 19 Jun | from NNW 336 deg (1.1 m/s) | from E 83 deg (2.1 m/s) | from E 88 deg (1.3 m/s) | from NE 36 deg (1.2 m/s) |
| **20 Jun** | from **NNW 328 deg** (1.8 m/s) | from **E 91 deg** (4.4 m/s) | from **E 95 deg** (3.4 m/s) | from NE 47 deg (1.0 m/s) |
| 21 Jun | from WSW 250 deg (3.4 m/s) | from WSW 245 deg (5.1 m/s) | from SW 234 deg (2.1 m/s) | from WSW 242 deg (1.7 m/s) |
| 22 Jun | from WSW 251 deg (2.6 m/s) | from W 266 deg (8.2 m/s) | from W 270 deg (6.9 m/s) | from W 269 deg (5.3 m/s) |

So on the event day the piedmont has a shallow north-westerly flow at 850 hPa and an easterly flow of 3-5 m/s at 700-600 hPa, with the easterly turning to south-westerly on 21 June and westerly on 22 June. The directional shear between 850 hPa and 600 hPa is what the convergence of Section 3.3 sits in.

## 3. Six-day change of the geopotential height

| level | 17 Jun | 22 Jun | change | June mean | anomaly on 22 Jun | 6-day change vs all sliding 6-day changes |
| --- | --- | --- | --- | --- | --- | --- |
| 500 hPa | 585.0 | 579.7 | -5.2 dam | 580.9 dam | -1.2 dam | -5.2 dam, 11th percentile of 55 samples (sd 4.73) |
| 600 hPa | 440.4 | 435.4 | -4.9 dam | 438.5 dam | -3.1 dam | -4.9 dam, 4th percentile of 24 samples (sd 3.13) |
| 650 hPa | 375.1 | 370.6 | -4.5 dam | 373.4 dam | -2.8 dam | -4.5 dam, 4th percentile of 24 samples (sd 2.76) |
| 700 hPa | 313.4 | 309.7 | -3.8 dam | 311.4 dam | -1.8 dam | -3.8 dam, 18th percentile of 55 samples (sd 4.49) |

## 4. Which levels are usable (height of the pressure surface)

Standard-atmosphere height of each surface, and the plateaus that rise above it, where the ERA5 values are extrapolated below ground:

| level | approx. height | plateau above it |
| --- | --- | --- |
| 700 hPa | about 3000 m | Tibetan Plateau interior, Pamir, Karakoram |
| 650 hPa | about 3500 m | Tibetan Plateau interior, Pamir, Karakoram |
| 600 hPa | about 4400 m | Tibetan Plateau interior (mean about 4500 m), Pamir, Karakoram |
| 500 hPa | about 5500 m | none over the study region - the surface is above the plateau |

The Tarim Basin and the Hotan piedmont are at 1000-2000 m, so all four levels are real atmosphere there and can be read directly.

