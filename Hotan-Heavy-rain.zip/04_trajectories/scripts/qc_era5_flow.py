"""Cross-check the trajectories against the ERA5 moisture transport of Fig. 4.

Figs. 3-4 of the manuscript attribute the 20 June moisture reaching the Hotan
rainfall centre to a transport that arrives from the west and north-west and
converges against the Kunlun piedmont. This script asks the mirror question of
the HYSPLIT output: where were the parcels a day and five days earlier? It uses
the cached flux fields (``fields_hotan.npz`` of the sibling ERA5 project)
because the raw ERA5 NetCDF files need a NetCDF4/HDF5 reader that is not
installed in the PySPLIT environment.

Two numbers are reported:

* the direction of the 20 June vertically integrated moisture flux at the
  rainfall centre and averaged over the Hotan mask - the Fig. 3/4 result;
* the direction from the launch point to each trajectory's position 24 h earlier
  - the HYSPLIT result.

Agreement means the trajectories are consistent with the transport that the
moisture-flux analysis describes.
"""

from __future__ import annotations

import os

import numpy as np
import pandas as pd

REPO = os.path.dirname(os.path.dirname(os.path.abspath(__file__)))
NPZ = os.path.join(REPO, "..", "ERA5_vapor flux_divergence--daily",
                   "outputs", "hotan", "fields_hotan.npz")
TRAJ_CSV = os.path.join(REPO, "outputs", "traj_alongtrack.csv")
POINT = (81.91756, 36.84699)
FLUX_DAY = "2026-06-20"
LEVELS = (800, 650)


def to_compass(dx, dy):
    """Direction (deg from north) of the vector (dx east, dy north)."""
    return (np.degrees(np.arctan2(dx, dy)) + 360.0) % 360.0


def compass_name(deg):
    names = ["N", "NNE", "NE", "ENE", "E", "ESE", "SE", "SSE",
             "S", "SSW", "SW", "WSW", "W", "WNW", "NW", "NNW"]
    return names[int((deg + 11.25) % 360 // 22.5)]


def bearing_from(lat0, lon0, lat1, lon1):
    p0, p1 = np.radians(lat0), np.radians(lat1)
    dl = np.radians(lon1 - lon0)
    y = np.sin(dl) * np.cos(p1)
    x = np.cos(p0) * np.sin(p1) - np.sin(p0) * np.cos(p1) * np.cos(dl)
    return (np.degrees(np.arctan2(y, x)) + 360.0) % 360.0


def main():
    d = np.load(NPZ)
    lon, lat = d["lon"], d["lat"]
    mask = d["mask"].astype(bool)                 # Hotan prefecture cells
    qx = d["Qx_" + FLUX_DAY]
    qy = d["Qy_" + FLUX_DAY]

    i = int(np.argmin(np.abs(lat - POINT[1])))
    j = int(np.argmin(np.abs(lon - POINT[0])))
    flux_dir = to_compass(qx[i, j], qy[i, j])
    print("20 June vertically integrated moisture flux")
    print("  at the rainfall-centre cell (%.2fE %.2fN): %6.1f kg/m/s toward %s "
          "(%.0f deg)"
          % (lon[j], lat[i], np.hypot(qx[i, j], qy[i, j]),
             compass_name(flux_dir), flux_dir))
    mm = mask & np.isfinite(qx) & np.isfinite(qy)
    mx, my = qx[mm].mean(), qy[mm].mean()
    dir_nat = to_compass(mx, my)
    print("  area mean over the Hotan mask:               %6.1f kg/m/s toward %s "
          "(%.0f deg)"
          % (np.hypot(mx, my), compass_name(dir_nat), dir_nat))

    df = pd.read_csv(TRAJ_CSV)
    print("\nHYSPLIT: direction from the launch point to the -24 h / -120 h "
          "position")
    print("  %-6s %-16s %-22s %-22s" % ("level", "launch", "-24 h", "-120 h"))
    for level in LEVELS:
        for launch in sorted(df[df.level_hpa == level].launch_utc.unique()):
            sub = df[(df.level_hpa == level) & (df.launch_utc == launch)]
            out = []
            for lead in (-24, -120):
                r = sub[sub.lead_h == lead].iloc[0]
                b = bearing_from(POINT[1], POINT[0], r.lat, r.lon)
                out.append("%s (%.0f$^\\circ$) %.0f hPa"
                           % (compass_name(b), b, r.pressure_hpa))
            print("  %-6d %-16s %-22s %-22s"
                  % (level, launch, out[0], out[1]))


if __name__ == "__main__":
    main()
