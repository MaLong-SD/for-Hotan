"""Compact daily pathway table (mean over the four launch times) by level.

Hotan, 20 June 2026: shows where the 650 and 800 hPa parcels were on each of the
five days before the event, so the pathway of the moisture can be read day by
day. Also prints one individual trajectory per level at full daily resolution.
"""

from __future__ import annotations

import os

import pandas as pd

REPO = os.path.dirname(os.path.dirname(os.path.abspath(__file__)))
OUTDIR = os.path.join(REPO, "outputs")


def main():
    df = pd.read_csv(os.path.join(OUTDIR, "traj5_alongtrack.csv"))
    df = df[df.lead_h % 24 == 0].copy()
    df["day"] = (-df.lead_h / 24).astype(int)
    g = (df.groupby(["level_hpa", "day"])
           .agg(lat=("lat", "mean"), lon=("lon", "mean"),
                p=("pressure_hpa", "mean"), q=("q_gkg", "mean"),
                lat_sd=("lat", "std"), lon_sd=("lon", "std"))
           .reset_index())
    print("%-6s %-4s %8s %8s %8s %8s %8s" %
          ("level", "day", "lat", "lon", "p(hPa)", "q(g/kg)", "spread"))
    for _, r in g.iterrows():
        print("%-6d %-4d %8.1f %8.1f %8.0f %8.2f %8.1f" %
              (r.level_hpa, r.day, r.lat, r.lon, r.p, r.q,
               max(r.lat_sd, r.lon_sd)))

    for level in (800, 650):
        print("\nsingle-trajectory detail, %d hPa 00 UTC:" % level)
        d = df[(df.level_hpa == level)
               & (df.launch_utc.str[11:13] == "00")].sort_values(
                   "day", ascending=False)
        print(d[["day", "lat", "lon", "pressure_hpa", "q_gkg", "rh_pct",
                 "terrain_m"]].to_string(index=False))

    print("\nwhole five-day envelope by level (30-minute points):")
    full = pd.read_csv(os.path.join(OUTDIR, "traj5_alongtrack.csv"))
    for level in (800, 650):
        s = full[full.level_hpa == level]
        print("  %d hPa: lon %.1f to %.1f E, lat %.1f to %.1f N, "
              "p %.0f to %.0f hPa, q %.1f to %.1f g/kg"
              % (level, s.lon.min(), s.lon.max(), s.lat.min(), s.lat.max(),
                 s.pressure_hpa.min(), s.pressure_hpa.max(),
                 s.q_gkg.min(), s.q_gkg.max()))

    print("\npressure range covered inside each source box, 5-day set:")
    boxes = {"Tarim Basin": (76, 90, 36, 42),
             "Tianshan / Dzungaria": (72, 90, 42, 48),
             "Aral-Caspian": (52, 72, 38, 50),
             "NW India / Pakistan": (68, 80, 24, 34),
             "Western Tibet": (76, 92, 28, 36),
             "Arabian Sea": (55, 75, 8, 24)}
    for label, (x0, x1, y0, y1) in boxes.items():
        for lvl in (800, 650):
            s = full[full.level_hpa == lvl]
            s = s[(s.lon >= x0) & (s.lon <= x1)
                  & (s.lat >= y0) & (s.lat <= y1)]
            if len(s):
                print("  %-22s %d hPa: %4d points, p %.0f-%.0f hPa, "
                      "q %.1f-%.1f g/kg"
                      % (label, lvl, len(s), s.pressure_hpa.min(),
                         s.pressure_hpa.max(), s.q_gkg.min(), s.q_gkg.max()))
            else:
                print("  %-22s %d hPa: no points inside the box" % (label, lvl))


if __name__ == "__main__":
    main()
