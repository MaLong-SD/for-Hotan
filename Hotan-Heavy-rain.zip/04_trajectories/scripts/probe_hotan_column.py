"""Measure the MSL height -> pressure ladder of the Hotan column, 20 June 2026.

Same idea as ``probe_level_ladder.py``, but for the Hotan launch point and date:
one short HYSPLIT run per MSL height, read the pressure HYSPLIT reports at
t = 0 with the production SETUP.CFG (kmsl = 1, delt = 6 min), and report the
height closest to each target pressure. The GDAS1 1 degree terrain at the
Kunlun piedmont is much lower than the GEBCO terrain used in the flux figures,
so the 800 hPa launch has to be checked against the model column rather than
assumed.

The terrain pressure printed alongside each ladder step is the GDAS1 surface
pressure at the launch point: every launch height must stay above it.

Run:  python scripts\\probe_hotan_column.py
"""

from __future__ import annotations

import os
import shutil
import subprocess

from run_backtraj import (REPO, EXE, ASCDATA, LAUNCH_LAT, LAUNCH_LON,
                          MET_FILES, SETUP, control_text, read_start_row)

WORK = os.path.join(REPO, "run", "_hotan_ladder")
HEIGHTS = list(range(1000, 5401, 200))
TARGETS = (850, 800, 750, 700, 650, 600, 550)
LAUNCH = (2026, 6, 20, 0)


def main():
    os.makedirs(WORK, exist_ok=True)
    shutil.copy(ASCDATA, os.path.join(WORK, "ASCDATA.CFG"))
    with open(os.path.join(WORK, "SETUP.CFG"), "w") as fh:
        fh.write(SETUP)

    print("launch point %.5f N, %.5f E, %04d-%02d-%02d %02d UTC"
          % (LAUNCH_LAT, LAUNCH_LON, LAUNCH[0], LAUNCH[1], LAUNCH[2], LAUNCH[3]))
    print("%10s %10s %10s" % ("height(m)", "p(hPa)", "terrain(hPa)"))

    table = []
    for h in HEIGHTS:
        year, month, day, hour = LAUNCH
        with open(os.path.join(WORK, "CONTROL"), "w") as fh:
            fh.write(control_text(LAUNCH_LAT, LAUNCH_LON, h, year, month, day,
                                  hour, 20000.0, MET_FILES, run=-1))
        for stale in ("tdump", "MESSAGE", "WARNING"):
            p = os.path.join(WORK, stale)
            if os.path.exists(p):
                os.remove(p)
        proc = subprocess.run([EXE], cwd=WORK, capture_output=True, text=True)
        tdump = os.path.join(WORK, "tdump")
        if not os.path.exists(tdump):
            print("%10d   FAILED rc=%s" % (h, proc.returncode))
            continue
        names, row = read_start_row(tdump)
        press = row[12 + names.index("PRESSURE")]
        terrain = row[12 + names.index("TERR_MSL")]
        table.append((h, press))
        print("%10d %10.1f %10.0f" % (h, press, terrain))

    print("\nclosest MSL height for each target level:")
    for target in TARGETS:
        best = min(table, key=lambda t: abs(t[1] - target))
        flag = "" if best[1] <= target + 6.0 else "   <-- lands above the target"
        print("  %4d hPa -> %5d m MSL (gives %.1f hPa)%s"
              % (target, best[0], best[1], flag))


if __name__ == "__main__":
    main()
