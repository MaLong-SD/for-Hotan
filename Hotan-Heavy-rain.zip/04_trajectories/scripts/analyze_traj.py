"""Load the HYSPLIT output with PySPLIT and characterise the 20-day back-trajectories.

Hotan, 20 June 2026: eight parcels (2 levels x 4 launch times) started at the
reported rainfall centre of the 19-21 June event.

Writes
    outputs/traj_alongtrack.csv   hourly along-track data for all trajectories
    outputs/traj_summary.csv      per-trajectory summary
    outputs/traj_summary.md       human-readable summary of what the run shows
"""

from __future__ import annotations

import os
import re

import numpy as np
import pandas as pd

import pysplit

from qc_era5_flow import to_compass, compass_name

REPO = os.path.dirname(os.path.dirname(os.path.abspath(__file__)))
TRAJ_DIR = os.path.join(REPO, "run", "traj")
OUTDIR = os.path.join(REPO, "outputs")
os.makedirs(OUTDIR, exist_ok=True)
NPZ = os.path.join(REPO, "..", "ERA5_vapor flux_divergence--daily",
                   "outputs", "hotan", "fields_hotan.npz")

# The high-flux layer identified from the 20 June vertical sections (Figs. 3-4 of
# the manuscript): the per-level flux density peaks at 650 hPa along the centre's
# latitude and at 850 hPa along its longitude, and the layer holding at least
# half of the section peak spans 850-550 hPa. The two launch levels are 650 and
# 800 hPa: 650 hPa is the section peak, and 800 hPa is the lowest level that
# exists above the GDAS1 ground at the rain centre.
LAYER_BOTTOM, LAYER_TOP = 800.0, 650.0
PROFILE_POINT = (81.91756, 36.84699)     # lon, lat of the rainfall centre
FLUX_DAY = "2026-06-20"
WINDOW_H = -120          # the moisture-relevant window (first five days)


def bearing_from(lat0, lon0, lat1, lon1):
    """Initial great-circle bearing (deg from north) from point 0 to point 1."""
    p0, p1 = np.radians(lat0), np.radians(lat1)
    dl = np.radians(lon1 - lon0)
    y = np.sin(dl) * np.cos(p1)
    x = np.cos(p0) * np.sin(p1) - np.sin(p0) * np.cos(p1) * np.cos(dl)
    return (np.degrees(np.arctan2(y, x)) + 360.0) % 360.0


compass = compass_name


def parse_name(name):
    """btrj_650hPa_3800m_2026062000 -> (650, '2026-06-20 00:00')"""
    m = re.match(r"btrj_(\d+)hPa_(\d+)m_(\d{10})", name)
    if m is None:
        raise ValueError("unexpected trajectory name: %s" % name)
    level, height, stamp = int(m.group(1)), int(m.group(2)), m.group(3)
    when = "%s-%s-%s %s:00" % (stamp[0:4], stamp[4:6], stamp[6:8], stamp[8:10])
    return level, height, when


def main():
    group = pysplit.make_trajectorygroup(os.path.join(TRAJ_DIR, "*"))
    print("loaded %d trajectories with PySPLIT" % group.trajcount)

    rows = []
    summaries = []
    for traj in group:
        level, height, when = parse_name(traj.filename)
        d = traj.data
        lat = d.geometry.apply(lambda p: p.y).values
        lon = d.geometry.apply(lambda p: p.x).values
        hgt = d.geometry.apply(lambda p: p.z).values
        lead = d["Timestep"].values                      # 0, -1, ... -480
        for i in range(len(d)):
            rows.append({
                "name": traj.filename,
                "level_hpa": level,
                "launch_utc": when,
                "lead_h": lead[i],
                "time_utc": d["DateTime"].values[i],
                "lat": lat[i], "lon": lon[i], "height_m": hgt[i],
                "pressure_hpa": d["Pressure"].values[i],
                "temp_C": d["Temperature_C"].values[i],
                "rh_pct": d["Relative_Humidity"].values[i],
                "q_gkg": d["Specific_Humidity"].values[i],
                "terrain_m": d["Terrain_Altitude"].values[i],
            })

        pres = d["Pressure"].values
        q = d["Specific_Humidity"].values
        inlayer = (pres >= LAYER_TOP) & (pres <= LAYER_BOTTOM)
        win = lead >= WINDOW_H                       # first five days
        i5 = int(np.argmin(np.abs(lead - WINDOW_H)))  # step closest to -120 h
        brg = bearing_from(PROFILE_POINT[1], PROFILE_POINT[0],
                           lat[i5], lon[i5])
        i24 = int(np.argmin(np.abs(lead + 24.0)))
        brg24 = bearing_from(PROFILE_POINT[1], PROFILE_POINT[0],
                             lat[i24], lon[i24])
        # moisture history: HYSPLIT reaches the target at i=0, so the earliest
        # time steps are the far end of the backward path
        imax = int(np.nanargmax(q))
        summaries.append({
            "name": traj.filename,
            "level_hpa": level,
            "launch_utc": when,
            "hours": len(d),
            "q_at_target_gkg": q[0],
            "q_max_gkg": q[imax],
            "q_max_time": str(pd.Timestamp(d["DateTime"].values[imax])),
            "q_max_lat": lat[imax],
            "q_max_lon": lon[imax],
            "q_max_pressure_hpa": pres[imax],
            "hours_in_flux_layer": int(inlayer.sum()),
            "frac_in_flux_layer": inlayer.mean(),
            "min_pressure_hpa": float(np.nanmin(pres)),
            "max_height_m": float(np.nanmax(hgt)),
            "end_lat": lat[-1], "end_lon": lon[-1],
            "end_pressure_hpa": pres[-1],
            "hours_above_layer_top": int((pres < LAYER_TOP).sum()),
            "hours_below_layer_bottom": int((pres > LAYER_BOTTOM).sum()),
            "lat_5day": lat[i5], "lon_5day": lon[i5],
            "lat_24h": lat[i24], "lon_24h": lon[i24],
            "pressure_5day": pres[i5], "q_5day": q[i5],
            "pressure_24h": pres[i24], "q_24h": q[i24],
            "bearing_5day_deg": brg, "bearing_5day": compass(brg),
            "bearing_24h_deg": brg24, "bearing_24h": compass(brg24),
            "frac_in_layer_first5d": float(inlayer[win].mean()),
        })

    df = pd.DataFrame(rows)
    csv_path = os.path.join(OUTDIR, "traj_alongtrack.csv")
    df.to_csv(csv_path, index=False)
    print("wrote %s (%d rows)" % (csv_path, len(df)))

    s = pd.DataFrame(summaries).sort_values(["level_hpa", "launch_utc"])
    s.to_csv(os.path.join(OUTDIR, "traj_summary.csv"), index=False)

    lines = []
    lines.append("# 20-day backward trajectories from the 20 June 2026 Hotan rainfall centre\n")
    lines.append("Launch point: %.5f N, %.5f E (Aoyituoghelake Township, Yutian "
                 "County - the reported rainfall centre of the 19-21 June 2026 "
                 "event).\n" % (PROFILE_POINT[1], PROFILE_POINT[0]))
    lines.append("Met data: GDAS1 (1 deg, 3-hourly).  Runtime -480 h.  "
                 "Vertical motion from the meteorology (CONTROL option 0), "
                 "MSL launch heights (SETUP.CFG kmsl = 1).\n")
    lines.append("\n## Per-trajectory summary\n")
    lines.append("| level (hPa) | launch (UTC) | q at target (g/kg) | q max (g/kg) | "
                 "q max location | q max level (hPa) | hours in 650-800 hPa | "
                 "min p (hPa) | max height (m) | end point |")
    lines.append("| --- | --- | --- | --- | --- | --- | --- | --- | --- | --- |")
    for _, r in s.iterrows():
        lines.append("| %d | %s | %.2f | %.2f | %.2fE, %.2fN | %.0f | %d (%.0f%%) | "
                     "%.0f | %.0f | %.2fE, %.2fN |"
                     % (r.level_hpa, r.launch_utc, r.q_at_target_gkg, r.q_max_gkg,
                        r.q_max_lon, r.q_max_lat, r.q_max_pressure_hpa,
                        r.hours_in_flux_layer, 100 * r.frac_in_flux_layer,
                        r.min_pressure_hpa, r.max_height_m, r.end_lon, r.end_lat))
    lines.append("")
    lines.append("## Notes\n")
    lines.append("- `q at target` is the specific humidity HYSPLIT reports at the "
                 "arrival point (lead time 0), i.e. the moisture content of the air "
                 "that reached the rainfall centre.\n")
    lines.append("- `q max` is the moistest point along the backward path; its "
                 "location is the candidate moisture-source region for that level.\n")
    lines.append("- `hours in 650-800 hPa` counts hourly steps inside the layer that "
                 "carries the largest per-level moisture-flux density in the 20 June "
                 "sections of the manuscript's Fig. 4.\n")

    lines.append("\n## Where the air was five days earlier (-120 h)\n")
    lines.append("| level (hPa) | launch (UTC) | position 5 days back | p (hPa) | "
                 "q (g/kg) | direction the air came from | % of window in "
                 "650-800 hPa |")
    lines.append("| --- | --- | --- | --- | --- | --- | --- |")
    for _, r in s.iterrows():
        lines.append("| %d | %s | %.2fE, %.2fN | %.0f | %.2f | %s (%.0f$^\\circ$) "
                     "| %.0f%% |"
                     % (r.level_hpa, r.launch_utc, r.lon_5day, r.lat_5day,
                        r.pressure_5day, r.q_5day, r.bearing_5day,
                        r.bearing_5day_deg, 100 * r.frac_in_layer_first5d))
    lines.append("")

    in_layer_5d = float(s.frac_in_layer_first5d.mean())

    # ---- how close the parcels are, one day before arrival
    def gc_km(lat1, lon1, lat2, lon2):
        p1, p2 = np.radians(lat1), np.radians(lat2)
        dp = p2 - p1
        dl = np.radians(lon2 - lon1)
        a = np.sin(dp / 2) ** 2 + np.cos(p1) * np.cos(p2) * np.sin(dl / 2) ** 2
        return 6371.0 * 2 * np.arcsin(np.sqrt(a))

    dist24 = gc_km(PROFILE_POINT[1], PROFILE_POINT[0],
                   s["lat_24h"].values, s["lon_24h"].values)
    dist5 = gc_km(PROFILE_POINT[1], PROFILE_POINT[0],
                  s["lat_5day"].values, s["lon_5day"].values)
    near24 = int((dist24 <= 500.0).sum())
    sector24 = {}
    for name, lo, hi in (("W-NW (240-330)", 240, 330),
                         ("N-NE (330-90)", 330, 360), ("S-SW (90-240)", 90, 240)):
        if name == "N-NE (330-90)":
            n = int((s.bearing_5day_deg >= 330).sum()
                    + (s.bearing_5day_deg < 90).sum())
        else:
            n = int(((s.bearing_5day_deg >= lo)
                     & (s.bearing_5day_deg < hi)).sum())
        sector24[name] = n

    # ---- consistency with the Fig. 3/4 moisture transport
    d = np.load(NPZ)
    lon_g, lat_g = d["lon"], d["lat"]
    mask = d["mask"].astype(bool)
    qx, qy = d["Qx_" + FLUX_DAY], d["Qy_" + FLUX_DAY]
    ig = int(np.argmin(np.abs(lat_g - PROFILE_POINT[1])))
    jg = int(np.argmin(np.abs(lon_g - PROFILE_POINT[0])))
    cell_dir = to_compass(qx[ig, jg], qy[ig, jg])
    mm = mask & np.isfinite(qx) & np.isfinite(qy)
    nat_dir = to_compass(qx[mm].mean(), qy[mm].mean())
    lines.append("\n## Consistency with the Fig. 3/4 moisture transport\n")
    lines.append("- ERA5 20 June vertically integrated flux at the rainfall-centre "
                 "cell: %.0f kg m$^{-1}$ s$^{-1}$ toward %s (%.0f$^\\circ$).\n"
                 % (float(np.hypot(qx[ig, jg], qy[ig, jg])),
                    compass_name(cell_dir), cell_dir))
    lines.append("- ERA5 20 June area mean over the Hotan prefecture: "
                 "%.0f kg m$^{-1}$ s$^{-1}$ toward %s (%.0f$^\\circ$); the "
                 "prefecture is net convergent that day (+9.9 mm day$^{-1}$) "
                 "and the strongest convergence sits on the piedmont just "
                 "south-west of this point.\n"
                 % (float(np.hypot(qx[mm].mean(), qy[mm].mean())),
                    compass_name(nat_dir), nat_dir))
    lines.append("- HYSPLIT: one day before arrival, %d of %d parcels lay "
                 "within 500 km of the centre and all eight were in the "
                 "750-900 hPa layer. Five days back, %d of %d parcels were west "
                 "or north-west of the centre (240-330$^\\circ$), %d were north "
                 "or north-east (330-90$^\\circ$) and %d came from the south or "
                 "south-west (90-240$^\\circ$); "
                 "the five-day positions lie %.0f-%.0f km away.\n"
                 % (near24, len(s),
                    sector24["W-NW (240-330)"], len(s), sector24["N-NE (330-90)"],
                    sector24["S-SW (90-240)"], dist5.min(), dist5.max()))
    for lvl, desc in ((800, "along the Tarim Basin floor west and north-west of "
                            "Hotan"),
                      (650, "over the Tianshan and the eastern Tarim margin to "
                            "the north and north-east")):
        sub = s[s.level_hpa == lvl]
        lines.append("- The air that arrived at %d hPa came from %s: its five-day "
                     "positions span %.1f-%.1f$^\\circ$E and %.1f-%.1f$^\\circ$N, "
                     "so no remote ocean is involved at this level.\n"
                     % (lvl, desc, sub.lon_5day.min(), sub.lon_5day.max(),
                        sub.lat_5day.min(), sub.lat_5day.max()))
    lines.append("- On average %.0f%% of the first 120 hours of each trajectory "
                 "stays inside the 650-800 hPa high-flux layer.\n"
                 % (100 * in_layer_5d))
    overall_in_layer = float(s.frac_in_flux_layer.mean())
    lines.append("- Averaged over the whole 480 hours the in-layer fraction is "
                 "%.0f%%: the parcels leave the 650-800 hPa band quickly, which "
                 "is why the first five days should be read as the transport "
                 "signal and the rest of the 20-day path as background. By -480 h "
                 "the parcels have scattered from the central North Atlantic to "
                 "the central Pacific, so the long run carries no source "
                 "information for this event.\n" % (100 * overall_in_layer))
    summary_path = os.path.join(OUTDIR, "traj_summary.md")
    with open(summary_path, "w", encoding="utf-8") as fh:
        fh.write("\n".join(lines))
    print("wrote %s and outputs/traj_summary.csv" % summary_path)

    print()
    print(s[["level_hpa", "launch_utc", "q_at_target_gkg", "q_max_gkg",
             "q_max_lat", "q_max_lon", "q_max_pressure_hpa",
             "hours_in_flux_layer", "min_pressure_hpa", "max_height_m"]]
          .to_string(index=False))


if __name__ == "__main__":
    main()
