"""Find where each backward trajectory enters the Hotan prefecture.

A backward trajectory starts inside the prefecture at the rainfall centre and
leaves it as it is followed back in time. The last point still inside the border
is therefore the place where the air entered the prefecture, travelling forward.
This script reports those crossings and the window that contains them all.

The boundary is the Hotan prefecture polygon used by the ERA5 moisture-flux
figures (``hotan\\hotan.shp`` in the sibling ERA5 project), so the entry points and
the flux maps of the manuscript refer to the same region.
"""

from __future__ import annotations

import os

import numpy as np
import pandas as pd
from shapely.geometry import Point
from shapely.ops import unary_union

import geopandas as gpd

REPO = os.path.dirname(os.path.dirname(os.path.abspath(__file__)))
OUTDIR = os.path.join(REPO, "outputs")
HOTAN_SHP = os.path.join(REPO, "..", "ERA5_vapor flux_divergence--daily",
                         "hotan", "hotan.shp")
POINT = (81.91756, 36.84699)


def hotan():
    gdf = gpd.read_file(HOTAN_SHP)
    return unary_union(gdf.geometry.values)


def main():
    region = hotan()
    print("Hotan prefecture bounds: %.2f-%.2f E, %.2f-%.2f N"
          % (region.bounds[0], region.bounds[2],
             region.bounds[1], region.bounds[3]))

    doc = pd.read_csv(os.path.join(OUTDIR, "traj5_alongtrack.csv"))
    rows = []
    for name, g in doc.groupby("name"):
        # lead time runs 0 -> -120; going back in time the parcel leaves the
        # prefecture, so the last inside point is the entry point
        g = g.sort_values("lead_h", ascending=False)
        inside = [region.contains(Point(x, y))
                  for x, y in zip(g.lon.values, g.lat.values)]
        if not any(inside):
            print("!! %s never inside the prefecture" % name)
            continue
        idx = len(inside) - 1 - inside[::-1].index(True)
        r = g.iloc[idx]
        rows.append({"name": name, "level_hpa": r.level_hpa,
                     "launch": r.launch_utc[11:13],
                     "entry_lon": r.lon, "entry_lat": r.lat,
                     "lead_h_at_entry": r.lead_h,
                     "pressure_hpa": r.pressure_hpa, "q_gkg": r.q_gkg,
                     "n_inside": int(sum(inside))})

    out = pd.DataFrame(rows).sort_values(["level_hpa", "launch"])
    out.to_csv(os.path.join(OUTDIR, "traj5_entry_points.csv"), index=False)
    print(out.to_string(index=False))

    inside_time = out[(out.lead_h_at_entry < -1.0)
                      & (out.lead_h_at_entry > -119.0)]
    lat = list(out.entry_lat) + [POINT[1]]
    lon = list(out.entry_lon) + [POINT[0]]
    print("\nentry points span %.2f-%.2f E, %.2f-%.2f N"
          % (min(lon), max(lon), min(lat), max(lat)))
    print("parcels still inside the prefecture at -120 h: %d"
          % int((out.lead_h_at_entry <= -120.0).sum()))
    if len(inside_time):
        print("parcels that leave within the five-day window: %d, between "
              "%.1f and %.1f h before arrival"
              % (len(inside_time), inside_time.lead_h_at_entry.max(),
                 inside_time.lead_h_at_entry.min()))


if __name__ == "__main__":
    main()
