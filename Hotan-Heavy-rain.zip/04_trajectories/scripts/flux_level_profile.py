"""Locate the pressure level of the moisture-flux maximum in the 20 June sections.

Reads the cached fields behind the manuscript's Fig. 4 (ERA5, 23 levels
1000-200 hPa, 0.25 deg, ``fields_hotan.npz`` of the sibling ERA5 project) and
reports, for the section through the rainfall centre's latitude (36.85 N) and
the section through its longitude (81.92 E), which level carries the largest
per-level moisture-flux density. This is the diagnostic that selects the two
HYSPLIT launch levels: they are the two bracketing the level of the maximum.

Both sections are linearly interpolated to the exact centre coordinates, the
same way the manuscript figures cut them.

Run:  python scripts\\flux_level_profile.py
"""

from __future__ import annotations

import os

import numpy as np

REPO = os.path.dirname(os.path.dirname(os.path.abspath(__file__)))
NPZ = os.path.join(REPO, "..", "ERA5_vapor flux_divergence--daily",
                   "outputs", "hotan", "fields_hotan.npz")
DAY = "2026-06-20"
POINT_LAT = 36.84699      # rainfall centre, the section through its latitude
POINT_LON = 81.91756      # and through its longitude


def slice_at(field, coord, target, axis):
    """Linear interpolation of a field to ``target`` along ``axis``."""
    c = np.asarray(coord, dtype=float)
    order = np.argsort(c)
    c = c[order]
    a = np.take(np.asarray(field, dtype=float), order, axis=axis)
    i = int(np.clip(np.searchsorted(c, float(target)) - 1, 0, c.size - 2))
    w = (float(target) - c[i]) / (c[i + 1] - c[i])
    lo = np.take(a, i, axis=axis)
    hi = np.take(a, i + 1, axis=axis)
    return (1.0 - w) * lo + w * hi


def main():
    d = np.load(NPZ)
    lev = d["lev"]                      # (23,) 1000 -> 200 hPa
    lat = d["lat"]                      # (33,) 42 -> 34, descending
    lon = d["lon"]                      # (57,) 72 -> 86
    fld = d["fld_" + DAY]               # (23, 33, 57) g cm-1 hPa-1 s-1
    print("field %s: %s, levels %d-%d hPa" % (DAY, fld.shape, lev.min(), lev.max()))

    prof_lat = np.nanmax(slice_at(fld, lat, POINT_LAT, axis=1), axis=1)
    prof_lon = np.nanmax(slice_at(fld, lon, POINT_LON, axis=2), axis=1)
    col = slice_at(slice_at(fld, lon, POINT_LON, axis=2), lat, POINT_LAT, axis=1)

    print("\n  p(hPa)   max on %.2fN   max on %.2fE   at the centre"
          % (POINT_LAT, POINT_LON))
    for k, p in enumerate(lev):
        print("  %6.0f   %13.2f   %13.2f   %13.2f"
              % (p, prof_lat[k], prof_lon[k], col[k]))

    for label, prof in (("%.2f N section" % POINT_LAT, prof_lat),
                        ("%.2f E section" % POINT_LON, prof_lon),
                        ("centre column", col)):
        kmax = int(np.argmax(prof))
        half = 0.5 * prof[kmax]
        above = np.where(prof >= half)[0]
        print("\n%s: largest flux density %.2f at %.0f hPa"
              % (label, prof[kmax], lev[kmax]))
        print("   levels at or above 50%% of that peak: %s hPa"
              % ", ".join("%.0f" % lev[k] for k in above))

    print("\nlevels ranked by the largest of the two sections (g cm-1 hPa-1 s-1):")
    best = np.maximum(prof_lat, prof_lon)
    for k in np.argsort(best)[::-1][:6]:
        print("   %6.0f hPa : %6.2f" % (lev[k], best[k]))

    print("\nthe two launch levels, 650 and 800 hPa:")
    for target in (650, 800):
        k = int(np.argmin(np.abs(lev - target)))
        print("   %4.0f hPa : %.2f g cm-1 hPa-1 s-1 on the latitude section, "
              "%.2f on the longitude section" % (lev[k], prof_lat[k], prof_lon[k]))


if __name__ == "__main__":
    main()
