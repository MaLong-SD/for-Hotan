"""Drive HYSPLIT: 20-day backward trajectories from the 20 June 2026 rainfall maximum.

Launch point  : 36.84699 N, 81.91756 E - the reported rainfall centre of the
                19-21 June 2026 Hotan rainstorm, the township of Aoyituoghelake
                in Yutian County. This is the same point that the ERA5
                moisture-flux sections of Figs. 3-4 are cut through.
Launch times  : 00, 06, 12, 18 UTC on 20 June 2026.
Levels        : 650 and 800 hPa. The 20 June vertical sections give the largest
                per-level moisture-flux density at 650 hPa along the centre's
                latitude (5.01) and at 850 hPa along its longitude (6.46); the
                layer holding at least half of the section peak spans
                850-550 hPa. 650 hPa is that peak level. 850 hPa cannot be used
                at this point: the GDAS1 1 degree terrain here is 1913 m, i.e. a
                surface pressure of 811.7 hPa, so an 850 hPa launch would be
                clamped to the ground. 800 hPa (2000 m MSL -> 804.7 hPa) is the
                lowest level that exists at the rain centre and stands in for
                the low-level branch.
Runtime       : -480 h (20 days back).

Two HYSPLIT settings matter and are set explicitly here:

* ``kmsl = 1`` in SETUP.CFG.  Without it the CONTROL height is read as metres
  above ground, which is useless here because the launch cell sits on ~2000 m
  of terrain; with it, the height is read as metres above mean sea level, so the
  launch pressure can be matched to the pressure levels of the flux sections.
  The MSL heights for the target pressures come from the height ladder in
  ``probe_levels_and_order.py`` (e.g. 4500 m MSL -> 587 hPa at this point/time).

* Model top = 20000 m in CONTROL. HYSPLIT's usual 10000 m top truncates this
  trajectory at -475 h ("trajectory above data domain"); 15000, 20000 and
  25000 m all give the same 481-point trajectory, so 20000 m is a safe choice.

PySPLIT's own bulk generator is not used for the drive because it hard-codes a
10000 m model top in the CONTROL file it writes.  PySPLIT is used downstream
for loading, mapping and along-track analysis (see ``analyze_traj.py``), and the
output file names follow its ``*mon*YYYY*#``-style conventions.
"""

from __future__ import annotations

import os
import shutil
import subprocess

REPO = os.path.dirname(os.path.dirname(os.path.abspath(__file__)))
METEO_DIR = os.path.join(REPO, "data", "gdas1")
WORK = os.path.join(REPO, "run", "work")
TRAJ_DIR = os.path.join(REPO, "run", "traj")
LOG_DIR = os.path.join(REPO, "run", "logs")
EXE = r"C:\HYSPLIT\exec\hyts_std.exe"
ASCDATA = r"C:\HYSPLIT\working\ASCDATA.CFG"

LAUNCH_LAT = 36.84699
LAUNCH_LON = 81.91756
RUNTIME = -480          # hours; negative = backward
MODEL_TOP = 20000.0     # m

# (label, year, month, day, hour UTC)
LAUNCH_TIMES = [
    ("2026062000", 2026, 6, 20, 0),
    ("2026062006", 2026, 6, 20, 6),
    ("2026062012", 2026, 6, 20, 12),
    ("2026062018", 2026, 6, 20, 18),
]

# pressure level (hPa) -> MSL launch height (m), from the height ladder probes
# (scripts/probe_level_ladder.py / probe_hotan_column.py, run against the
# production SETUP.CFG at this launch point and time)
LEVELS = [
    (650, 3800),
    (800, 2000),
]

# Chronological order matters for readability only - the order probe showed
# HYSPLIT returns identical trajectories for a shuffled list.
MET_FILES = ["gdas1.may26.w5", "gdas1.jun26.w1", "gdas1.jun26.w2",
             "gdas1.jun26.w3"]

SETUP = "\n".join([
    " &SETUP",
    " tratio = 0.75,",
    # delt is the integration time step in minutes. Leaving it at 0 makes
    # HYSPLIT choose a step that is capped by the output interval tout, so a
    # 60-minute and a 30-minute output give different trajectories: over 120 h
    # they separate by 247 km, and by 558 km against a 5-minute run. Fixing
    # delt = 6 min makes tout pure output sampling (60 and 30 min then agree to
    # 0.00 km) and lands 2.9 km from the finest-step run, i.e. converged.
    " delt = 6.0,",
    " mgmin = 10,",
    " khmax = 9999,",
    " kmixd = 0,",
    " kmsl = 1,",
    " kagl = 0,",
    " k10m = 1,",
    " nstr = 0,",
    " mhrs = 9999,",
    " nver = 0,",
    " tout = 60,",
    " tm_pres = 1,",
    " tm_tpot = 0,",
    " tm_tamb = 1,",
    " tm_rain = 0,",
    " tm_mixd = 0,",
    " tm_relh = 1,",
    " tm_sphu = 1,",
    " tm_mixr = 0,",
    " tm_dswf = 0,",
    " tm_terr = 1,",
    " dxf = 1.00,",
    " dyf = 1.00,",
    " dzf = 0.01,",
    " messg = 'MESSAGE',",
    " /",
    "",
])


LEVELS_HEIGHT = {p: h for p, h in LEVELS}


def slug(level_hpa, stamp):
    """PySPLIT-friendly output name: keeps a 10-digit date run at the end."""
    return "btrj_{0}hPa_{1}m_{2}".format(level_hpa, LEVELS_HEIGHT[level_hpa], stamp)


def control_text(lat, lon, height, year, month, day, hour, top, met_files,
                 run=None):
    """CONTROL file for one backward trajectory."""
    if run is None:
        run = RUNTIME
    lines = ["{0:02d} {1:02d} {2:02d} {3:02d}\n".format(year % 100, month, day, hour),
             "1\n",
             "{0} {1} {2}\n".format(lat, lon, height),
             "{0}\n".format(run),
             "0\n",
             "{0}\n".format(top),
             "{0}\n".format(len(met_files))]
    for fname in met_files:
        lines.append(METEO_DIR.replace("\\", "/") + "/\n")
        lines.append(fname + "\n")
    lines.append("./\n")
    lines.append("tdump\n")
    return "".join(lines)


def read_start_row(tdump_path):
    """Return (variable names, first data row) from a HYSPLIT tdump file."""
    with open(tdump_path, encoding="ascii", errors="replace") as fh:
        lines = fh.readlines()
    names = []
    for ln in lines:
        if "PRESSURE" in ln and not names:
            names = ln.split()[1:]
        parts = ln.split()
        if len(parts) >= 13:
            try:
                row = [float(x) for x in parts]
            except ValueError:
                continue
            if not names:
                raise RuntimeError("no variable header in %s" % tdump_path)
            return names, row
    raise RuntimeError("no data row in %s" % tdump_path)


def main():
    for d in (WORK, TRAJ_DIR, LOG_DIR):
        os.makedirs(d, exist_ok=True)
    # clear previous trajectory output so a rerun at other levels cannot leave
    # stale files behind for the analysis glob to pick up
    for fname in os.listdir(TRAJ_DIR):
        if fname.startswith("btrj_"):
            os.remove(os.path.join(TRAJ_DIR, fname))
    for fname in os.listdir(LOG_DIR):
        if fname.startswith("btrj_"):
            os.remove(os.path.join(LOG_DIR, fname))
    shutil.copy(ASCDATA, os.path.join(WORK, "ASCDATA.CFG"))
    with open(os.path.join(WORK, "SETUP.CFG"), "w") as fh:
        fh.write(SETUP)

    manifest = []
    for stamp, year, month, day, hour in LAUNCH_TIMES:
        for level_hpa, height in LEVELS:
            name = slug(level_hpa, stamp)
            control_path = os.path.join(WORK, "CONTROL")
            with open(control_path, "w") as fh:
                fh.write(control_text(LAUNCH_LAT, LAUNCH_LON, height,
                                      year, month, day, hour, MODEL_TOP,
                                      MET_FILES))
            for stale in ("tdump", "MESSAGE", "WARNING"):
                p = os.path.join(WORK, stale)
                if os.path.exists(p):
                    os.remove(p)

            proc = subprocess.run([EXE], cwd=WORK, capture_output=True, text=True)
            tdump = os.path.join(WORK, "tdump")
            if proc.returncode != 0 or not os.path.exists(tdump):
                print("!! FAILED %s (rc=%s)" % (name, proc.returncode))
                print(proc.stdout[-500:], proc.stderr[-500:])
                continue

            names, row = read_start_row(tdump)
            pidx = 12 + names.index("PRESSURE")
            qidx = 12 + names.index("SPCHUMID")
            with open(tdump, encoding="ascii", errors="replace") as fh:
                npoints = sum(1 for ln in fh
                              if len(ln.split()) >= 13 and ln.split()[0][0].isdigit())
            last = None
            with open(tdump, encoding="ascii", errors="replace") as fh:
                for ln in fh:
                    parts = ln.split()
                    if len(parts) >= 13 and parts[0][0].isdigit():
                        last = parts

            shutil.move(tdump, os.path.join(TRAJ_DIR, name))
            for tag in ("MESSAGE", "WARNING"):
                src = os.path.join(WORK, tag)
                if os.path.exists(src):
                    shutil.copy(src, os.path.join(LOG_DIR, name + "." + tag))

            manifest.append({
                "name": name, "launch_utc": "%04d-%02d-%02d %02d:00"
                                              % (year, month, day, hour),
                "level_hpa": level_hpa, "msl_height_m": height,
                "start_pressure_hpa": "%.1f" % row[pidx],
                "start_sphumid_gkg": "%.2f" % row[qidx],
                "points": npoints,
                "end_lat": "%.2f" % float(last[9]),
                "end_lon": "%.2f" % float(last[10]),
            })
            print("%-28s target %4d hPa -> start %6.1f hPa  q=%5.2f g/kg  n=%d"
                  % (name, level_hpa, row[pidx], row[qidx], npoints))

    csv_path = os.path.join(REPO, "run", "manifest.csv")
    cols = ["name", "launch_utc", "level_hpa", "msl_height_m",
            "start_pressure_hpa", "start_sphumid_gkg", "points",
            "end_lat", "end_lon"]
    with open(csv_path, "w") as fh:
        fh.write(",".join(cols) + "\n")
        for m in manifest:
            fh.write(",".join(str(m[c]) for c in cols) + "\n")
    print("\nwrote %d trajectories to %s" % (len(manifest), TRAJ_DIR))
    print("manifest: %s" % csv_path)


if __name__ == "__main__":
    main()
