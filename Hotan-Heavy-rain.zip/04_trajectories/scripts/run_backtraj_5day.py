"""Dedicated five-day backward trajectories from the 20 June 2026 rainfall maximum.

Same launch point, levels and launch times as the 20-day set, but run for -120 h
with a 30-minute output interval instead of 60, so the short-window tracks are
sampled twice as finely. Everything else is held identical (kmsl = 1, 20000 m
model top, same GDAS1 weeks) so the first five days of the 20-day run can be used
as an independent check of this set.

Output goes to run/traj5 so it cannot be confused with the 20-day run/traj.
"""

from __future__ import annotations

import os
import shutil
import subprocess

from run_backtraj import (REPO, METEO_DIR, EXE, ASCDATA, LAUNCH_LAT,
                          LAUNCH_LON, LAUNCH_TIMES, LEVELS, MET_FILES, SETUP,
                          control_text, read_start_row, slug)

WORK = os.path.join(REPO, "run", "work5")
TRAJ_DIR = os.path.join(REPO, "run", "traj5")
LOG_DIR = os.path.join(REPO, "run", "logs5")

RUNTIME = -120          # hours
MODEL_TOP = 20000.0     # m, identical to the 20-day run
TOUT = 30               # minutes between output points


def main():
    for d in (WORK, TRAJ_DIR, LOG_DIR):
        os.makedirs(d, exist_ok=True)
    for fname in os.listdir(TRAJ_DIR):
        if fname.startswith("btrj_"):
            os.remove(os.path.join(TRAJ_DIR, fname))
    for fname in os.listdir(LOG_DIR):
        if fname.startswith("btrj_"):
            os.remove(os.path.join(LOG_DIR, fname))

    shutil.copy(ASCDATA, os.path.join(WORK, "ASCDATA.CFG"))
    setup = SETUP.replace(" tout = 60,", " tout = {0},".format(TOUT))
    assert "tout = {0},".format(TOUT) in setup, "tout override failed"
    with open(os.path.join(WORK, "SETUP.CFG"), "w") as fh:
        fh.write(setup)

    manifest = []
    for stamp, year, month, day, hour in LAUNCH_TIMES:
        for level_hpa, height in LEVELS:
            name = slug(level_hpa, stamp)
            with open(os.path.join(WORK, "CONTROL"), "w") as fh:
                fh.write(control_text(LAUNCH_LAT, LAUNCH_LON, height,
                                      year, month, day, hour, MODEL_TOP,
                                      MET_FILES, run=RUNTIME))
            for stale in ("tdump", "MESSAGE", "WARNING"):
                p = os.path.join(WORK, stale)
                if os.path.exists(p):
                    os.remove(p)

            proc = subprocess.run([EXE], cwd=WORK, capture_output=True, text=True)
            tdump = os.path.join(WORK, "tdump")
            if proc.returncode != 0 or not os.path.exists(tdump):
                print("!! FAILED %s (rc=%s)" % (name, proc.returncode))
                continue

            names, row = read_start_row(tdump)
            pidx = 12 + names.index("PRESSURE")
            qidx = 12 + names.index("SPCHUMID")
            rows = []
            with open(tdump, encoding="ascii", errors="replace") as fh:
                for ln in fh:
                    parts = ln.split()
                    if len(parts) >= 13 and parts[0][0].isdigit():
                        rows.append(parts)
            shutil.move(tdump, os.path.join(TRAJ_DIR, name))
            for tag in ("MESSAGE", "WARNING"):
                src = os.path.join(WORK, tag)
                if os.path.exists(src):
                    shutil.copy(src, os.path.join(LOG_DIR, name + "." + tag))

            manifest.append({
                "name": name,
                "launch_utc": "%04d-%02d-%02d %02d:00" % (year, month, day, hour),
                "level_hpa": level_hpa, "msl_height_m": height,
                "start_pressure_hpa": "%.1f" % row[pidx],
                "start_sphumid_gkg": "%.2f" % row[qidx],
                "points": len(rows),
            })
            print("%-28s target %4d hPa -> start %6.1f hPa  q=%5.2f g/kg  n=%d"
                  % (name, level_hpa, row[pidx], row[qidx], len(rows)))

    csv_path = os.path.join(REPO, "run", "manifest_5day.csv")
    cols = ["name", "launch_utc", "level_hpa", "msl_height_m",
            "start_pressure_hpa", "start_sphumid_gkg", "points"]
    with open(csv_path, "w") as fh:
        fh.write(",".join(cols) + "\n")
        for m in manifest:
            fh.write(",".join(str(m[c]) for c in cols) + "\n")
    print("\nwrote %d trajectories to %s" % (len(manifest), TRAJ_DIR))


if __name__ == "__main__":
    main()
