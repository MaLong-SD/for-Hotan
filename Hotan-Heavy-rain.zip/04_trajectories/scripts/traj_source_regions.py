"""Diagnostics behind the Results text: westerly background, level moisture, source boxes.

Answers three questions with numbers rather than impressions:

1. Is the 20-day background a west-to-east (westerly) transport?  Reported as the
   fraction of the forward path that moves eastward and the net zonal
   displacement, both computed with a cos(latitude) weighting and dateline-safe
   longitude differences.
2. Which level actually carries the moisture that arrives at the rainfall
   maximum?  Reported as specific humidity at lead time 0 and at -120 h, the
   pressure at which each path reaches its own moisture maximum, and the fraction
   of the path spent inside the 500-700 hPa flux layer.
3. Do the paths pass over each candidate source region, and what is the
   moisture content of the air while it is there?

Writes outputs/traj_region_stats.csv and prints everything.

Hotan, 20 June 2026: the boxes are the moisture-source candidates relevant to
the Tarim Basin - the basin itself, the Tianshan to the north, the Pamir-Alai to
the west, north-west India and the western Tibetan Plateau to the south, and the
Arabian Sea as the nearest large water body.
"""

from __future__ import annotations

import os

import numpy as np
import pandas as pd

REPO = os.path.dirname(os.path.dirname(os.path.abspath(__file__)))
OUTDIR = os.path.join(REPO, "outputs")

LAYER_BOTTOM, LAYER_TOP = 800.0, 650.0

# lon_min, lon_max, lat_min, lat_max
REGIONS = {
    "Tarim Basin": (76, 90, 36, 42),
    "Tianshan": (72, 90, 42, 48),
    "Pamir-Alai": (68, 76, 36, 42),
    "NW India/Pakistan": (68, 80, 24, 34),
    "Western Tibet": (76, 92, 28, 36),
    "Arabian Sea": (55, 75, 8, 24),
}

LEVELS = (800, 650)


def wrap_dlon(lon1, lon2):
    return ((lon2 - lon1 + 180.0) % 360.0) - 180.0


def main():
    long_df = pd.read_csv(os.path.join(OUTDIR, "traj_alongtrack.csv"))
    short_df = pd.read_csv(os.path.join(OUTDIR, "traj5_alongtrack.csv"))

    # ---------------------------------------------------------------- 1. westerly
    print("=" * 78)
    print("1. Is the 20-day background a westerly (west-to-east) transport?")
    print("   backward tracks are reversed, so the sequence runs forward in time")
    rows = []
    for name, g in long_df.groupby("name"):
        g = g.sort_values("lead_h")                  # -480 ... 0 = forward in time
        dlon = wrap_dlon(g.lon.values[:-1], g.lon.values[1:])
        dx = dlon * np.cos(np.radians(g.lat.values[:-1]))   # great-circle-ish
        east = dx > 0
        rows.append({
            "name": name, "level_hpa": g.level_hpa.iloc[0],
            "launch": g.launch_utc.iloc[0][11:13],
            "net_dlon_deg": float(dlon.sum()),
            "net_dx_deg": float(dx.sum()),
            "frac_steps_eastward": float(east.mean()),
            "frac_steps_westward": float((~east).mean()),
            "total_abs_dx_deg": float(np.abs(dx).sum()),
        })
    w = pd.DataFrame(rows).sort_values(["level_hpa", "launch"])
    print(w.to_string(index=False))
    print("\n  all trajectories: %.0f%% of hourly steps move eastward, "
          "%.0f%% westward"
          % (100 * w.frac_steps_eastward.mean(),
             100 * w.frac_steps_westward.mean()))
    print("  mean net zonal displacement (cos-lat weighted): %+.1f deg  "
          "(positive = net eastward)" % w.net_dx_deg.mean())
    print("  median net zonal displacement: %+.1f deg" % w.net_dx_deg.median())

    # ------------------------------------------------------- 2. level and moisture
    print()
    print("=" * 78)
    print("2. Which level carries the moisture that arrives?")
    rows = []
    for name, g in short_df.groupby("name"):
        g = g.sort_values("lead_h")
        q = g.q_gkg.values
        p = g.pressure_hpa.values
        imax = int(np.nanargmax(q))
        inlayer = (p >= LAYER_TOP) & (p <= LAYER_BOTTOM)
        rows.append({
            "level_hpa": g.level_hpa.iloc[0], "launch": g.launch_utc.iloc[0][11:13],
            "q_arrival": q[-1], "q_5day_back": q[0],
            "q_max": q[imax], "p_at_q_max": p[imax],
            "lon_at_q_max": g.lon.values[imax], "lat_at_q_max": g.lat.values[imax],
            "frac_in_layer": float(inlayer.mean()),
            "p_at_arrival": p[-1],
        })
    m = pd.DataFrame(rows).sort_values(["level_hpa", "launch"])
    print(m.to_string(index=False))
    print("\n  mean specific humidity at arrival, by launch level:")
    for lvl, g in m.groupby("level_hpa"):
        print("    %d hPa: q_arrival %.2f g/kg | q_max %.1f at %.0f hPa | "
              "in-layer %.0f%%"
              % (lvl, g.q_arrival.mean(), g.q_max.mean(),
                 g.p_at_q_max.mean(), 100 * g.frac_in_layer.mean()))

    # -------------------------------------------------------- 3. source-region boxes
    print()
    print("=" * 78)
    print("3. Do the paths cross each candidate source region?")
    for label, df in (("5-day", short_df), ("20-day", long_df)):
        print("\n  %s set, fraction of each path inside each box:" % label)
        head = "    %-14s %-6s" % ("region", "level") + "".join(
            "%12s" % ("%s UTC" % h) for h in ("00", "06", "12", "18"))
        print(head)
        for region, (x0, x1, y0, y1) in REGIONS.items():
            for lvl in LEVELS:
                cells = []
                for launch in ("00", "06", "12", "18"):
                    g = df[(df.level_hpa == lvl)
                           & (df.launch_utc.str[11:13] == launch)]
                    inside = ((g.lon >= x0) & (g.lon <= x1)
                              & (g.lat >= y0) & (g.lat <= y1))
                    cells.append(100.0 * inside.mean())
                print("    %-14s %-6d" % (region, lvl)
                      + "".join("%11.0f%%" % c for c in cells))

    print("\n  mean specific humidity while inside each box (5-day set):")
    print("    %-14s %-6s %8s %8s %8s" %
          ("region", "level", "q(g/kg)", "p(hPa)", "days"))
    for region, (x0, x1, y0, y1) in REGIONS.items():
        for lvl in LEVELS:
            g = short_df[short_df.level_hpa == lvl]
            inside = ((g.lon >= x0) & (g.lon <= x1)
                      & (g.lat >= y0) & (g.lat <= y1))
            sub = g[inside]
            print("    %-14s %-6d %8.2f %8.0f %8.1f"
                  % (region, lvl, sub.q_gkg.mean(), sub.pressure_hpa.mean(),
                     len(sub) * 0.5 / 24.0))

    w.to_csv(os.path.join(OUTDIR, "traj_westerly_stats.csv"), index=False)
    m.to_csv(os.path.join(OUTDIR, "traj_level_moisture.csv"), index=False)
    print("\nwrote outputs/traj_westerly_stats.csv and traj_level_moisture.csv")


if __name__ == "__main__":
    main()
