"""Humidity and relative-humidity signature at arrival, by level."""

import os

import pandas as pd

REPO = os.path.dirname(os.path.dirname(os.path.abspath(__file__)))


def main():
    d = pd.read_csv(os.path.join(REPO, "outputs", "traj5_alongtrack.csv"))
    print("Hotan, 20 June 2026 - at arrival (lead 0), mean over the four "
          "launch times:")
    print(d[d.lead_h == 0].groupby("level_hpa")
          .agg(q_gkg=("q_gkg", "mean"), rh_pct=("rh_pct", "mean"),
               p_hPa=("pressure_hpa", "mean")).round(2).to_string())

    mx = (d.groupby(["level_hpa", "name"]).rh_pct.max()
            .groupby("level_hpa").mean().round(0))
    print("\nmaximum relative humidity along each path:")
    print(mx.to_string())

    print("\nat -120 h (five days back):")
    print(d[d.lead_h == -120].groupby("level_hpa")
          .agg(q_gkg=("q_gkg", "mean"), rh_pct=("rh_pct", "mean"),
               p_hPa=("pressure_hpa", "mean")).round(2).to_string())

    print("\n800 hPa, net pressure change over the last day:")
    five = d[(d.level_hpa == 800) & (d.lead_h.isin([-24, 0]))]
    t = five.pivot_table(index="name", columns="lead_h",
                         values="pressure_hpa")
    t["dp_hPa_per_day"] = t[-24] - t[0]
    print(t.round(0).to_string())


if __name__ == "__main__":
    main()
