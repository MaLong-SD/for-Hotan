"""Load the dedicated five-day set with PySPLIT, summarise it, and QC it.

Writes
    outputs/traj5_alongtrack.csv   30-minute along-track data for the 5-day run
    outputs/traj5_summary.csv      per-trajectory summary
    outputs/traj5_summary.md       readable summary
    outputs/traj5_qc.md            agreement with the first 120 h of the 20-day run

The QC matters because the two runs share the launch point, levels, launch times,
meteorology and model settings and differ only in run length and output
interval. Matching positions over the shared 0 to -120 h window therefore tests
that neither run is sensitive to those two choices.
"""

from __future__ import annotations

import os

import numpy as np
import pandas as pd

import pysplit

from qc_era5_flow import to_compass, compass_name, bearing_from

REPO = os.path.dirname(os.path.dirname(os.path.abspath(__file__)))
TRAJ5_DIR = os.path.join(REPO, "run", "traj5")
OUTDIR = os.path.join(REPO, "outputs")

PROFILE_POINT = (81.91756, 36.84699)     # lon, lat; Hotan rainfall centre
LAYER_BOTTOM, LAYER_TOP = 800.0, 650.0


def parse_name(name):
    import re
    m = re.match(r"btrj_(\d+)hPa_(\d+)m_(\d{10})", name)
    level, stamp = int(m.group(1)), m.group(3)
    when = "%s-%s-%s %s:00" % (stamp[0:4], stamp[4:6], stamp[6:8], stamp[8:10])
    return level, when


def great_circle_km(lat1, lon1, lat2, lon2):
    p1, p2 = np.radians(lat1), np.radians(lat2)
    dp = p2 - p1
    dl = np.radians(lon2 - lon1)
    a = np.sin(dp / 2) ** 2 + np.cos(p1) * np.cos(p2) * np.sin(dl / 2) ** 2
    return 6371.0 * 2 * np.arcsin(np.sqrt(a))


def main():
    group = pysplit.make_trajectorygroup(os.path.join(TRAJ5_DIR, "*"))
    print("loaded %d five-day trajectories" % group.trajcount)

    rows, summary = [], []
    for traj in group:
        level, when = parse_name(traj.filename)
        d = traj.data
        lat = d.geometry.apply(lambda p: p.y).values
        lon = d.geometry.apply(lambda p: p.x).values
        hgt = d.geometry.apply(lambda p: p.z).values
        lead = d["Timestep"].values
        pres = d["Pressure"].values
        q = d["Specific_Humidity"].values
        for i in range(len(d)):
            rows.append({"name": traj.filename, "level_hpa": level,
                         "launch_utc": when, "lead_h": lead[i],
                         "time_utc": d["DateTime"].values[i],
                         "lat": lat[i], "lon": lon[i], "height_m": hgt[i],
                         "pressure_hpa": pres[i],
                         "temp_C": d["Temperature_C"].values[i],
                         "rh_pct": d["Relative_Humidity"].values[i],
                         "q_gkg": q[i],
                         "terrain_m": d["Terrain_Altitude"].values[i]})

        inlayer = (pres >= LAYER_TOP) & (pres <= LAYER_BOTTOM)
        imax = int(np.nanargmax(q))
        brg = bearing_from(PROFILE_POINT[1], PROFILE_POINT[0], lat[-1], lon[-1])
        summary.append({
            "name": traj.filename, "level_hpa": level, "launch_utc": when,
            "points": len(d),
            "q_at_target_gkg": q[0], "q_max_gkg": q[imax],
            "q_max_lat": lat[imax], "q_max_lon": lon[imax],
            "q_max_pressure_hpa": pres[imax],
            "frac_in_layer": inlayer.mean(),
            "end_lat": lat[-1], "end_lon": lon[-1], "end_pressure_hpa": pres[-1],
            "bearing_5day_deg": brg, "bearing_5day": compass_name(brg),
        })

    df = pd.DataFrame(rows)
    df.to_csv(os.path.join(OUTDIR, "traj5_alongtrack.csv"), index=False)
    s = pd.DataFrame(summary).sort_values(["level_hpa", "launch_utc"])
    s.to_csv(os.path.join(OUTDIR, "traj5_summary.csv"), index=False)
    print("wrote %d rows to outputs/traj5_alongtrack.csv" % len(df))

    # ---- QC against the first 120 h of the 20-day run
    long = pd.read_csv(os.path.join(OUTDIR, "traj_alongtrack.csv"))
    long = long[(long.lead_h >= -120) & (long.lead_h == long.lead_h.round())]
    both = df.merge(long, on=["name", "lead_h"], suffixes=("_5d", "_20d"))
    both["sep_km"] = great_circle_km(both.lat_5d, both.lon_5d,
                                     both.lat_20d, both.lon_20d)
    per = both.groupby("name").sep_km.agg(["max", "mean"]).reset_index()

    lines = ["# Five-day run vs the first 120 h of the 20-day run\n",
             "The two runs share launch point, levels, launch times, meteorology "
             "and model settings; they differ only in run length (-120 vs -480 h) "
             "and output interval (30 vs 60 min).\n",
             "| trajectory | mean separation (km) | max separation (km) |",
             "| --- | --- | --- |"]
    for _, r in per.iterrows():
        lines.append("| %s | %.2f | %.2f |" % (r["name"], r["mean"], r["max"]))
    lines.append("")
    lines.append("- Overall: mean %.2f km, maximum %.2f km over %d matched "
                 "hourly points." % (both.sep_km.mean(), both.sep_km.max(),
                                     len(both)))
    lines.append("- The two runs are therefore interchangeable over the shared "
                 "window, and the five-day tracks are not an artefact of the "
                 "shorter runtime.\n")
    with open(os.path.join(OUTDIR, "traj5_qc.md"), "w", encoding="utf-8") as fh:
        fh.write("\n".join(lines))
    print("QC: mean %.2f km, max %.2f km" % (both.sep_km.mean(), both.sep_km.max()))

    # ---- readable summary
    out = ["# Five-day backward trajectories from the 20 June 2026 Hotan "
           "rainfall centre\n",
           "Launch point 36.847 N, 81.918 E (Aoyituoghelake Township, Yutian "
           "County); 00, 06, 12, 18 UTC on 20 June 2026; 650/800 hPa; "
           "-120 h at a 30-minute output interval; GDAS1.\n",
           "## Per-trajectory summary\n",
           "| level (hPa) | launch (UTC) | q at target (g/kg) | q max (g/kg) | "
           "q max location | fraction of path in 650-800 hPa | position at "
           "-120 h | direction the air came from |",
           "| --- | --- | --- | --- | --- | --- | --- | --- |"]
    for _, r in s.iterrows():
        out.append("| %d | %s | %.2f | %.2f | %.2fE, %.2fN | %.0f%% | "
                   "%.2fE, %.2fN | %s (%.0f deg) |"
                   % (r.level_hpa, r.launch_utc, r.q_at_target_gkg, r.q_max_gkg,
                      r.q_max_lon, r.q_max_lat, 100 * r.frac_in_layer,
                      r.end_lon, r.end_lat, r.bearing_5day, r.bearing_5day_deg))
    out.append("")
    west = int(s.bearing_5day_deg.between(240, 330).sum())
    out.append("- %d of %d trajectories were in the W-WNW sector (240-330 deg) "
               "five days earlier." % (west, len(s)))
    out.append("- Mean fraction of the five-day path inside the 650-800 hPa "
               "high-flux layer: %.0f%%." % (100 * s.frac_in_layer.mean()))
    with open(os.path.join(OUTDIR, "traj5_summary.md"), "w", encoding="utf-8") as fh:
        fh.write("\n".join(out))
    print(s[["level_hpa", "launch_utc", "q_at_target_gkg", "q_max_gkg",
             "end_lat", "end_lon", "bearing_5day"]].to_string(index=False))


if __name__ == "__main__":
    main()
