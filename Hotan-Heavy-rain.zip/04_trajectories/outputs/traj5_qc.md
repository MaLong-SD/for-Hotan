# Five-day run vs the first 120 h of the 20-day run

The two runs share launch point, levels, launch times, meteorology and model settings; they differ only in run length (-120 vs -480 h) and output interval (30 vs 60 min).

| trajectory | mean separation (km) | max separation (km) |
| --- | --- | --- |
| btrj_650hPa_3800m_2026062000 | 0.00 | 0.00 |
| btrj_650hPa_3800m_2026062006 | 0.00 | 0.00 |
| btrj_650hPa_3800m_2026062012 | 0.00 | 0.00 |
| btrj_650hPa_3800m_2026062018 | 0.00 | 0.00 |
| btrj_800hPa_2000m_2026062000 | 0.00 | 0.00 |
| btrj_800hPa_2000m_2026062006 | 0.00 | 0.00 |
| btrj_800hPa_2000m_2026062012 | 0.00 | 0.00 |
| btrj_800hPa_2000m_2026062018 | 0.00 | 0.00 |

- Overall: mean 0.00 km, maximum 0.00 km over 968 matched hourly points.
- The two runs are therefore interchangeable over the shared window, and the five-day tracks are not an artefact of the shorter runtime.
