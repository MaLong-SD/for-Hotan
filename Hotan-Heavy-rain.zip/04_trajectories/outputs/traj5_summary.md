# Five-day backward trajectories from the 20 June 2026 Hotan rainfall centre

Launch point 36.847 N, 81.918 E (Aoyituoghelake Township, Yutian County); 00, 06, 12, 18 UTC on 20 June 2026; 650/800 hPa; -120 h at a 30-minute output interval; GDAS1.

## Per-trajectory summary

| level (hPa) | launch (UTC) | q at target (g/kg) | q max (g/kg) | q max location | fraction of path in 650-800 hPa | position at -120 h | direction the air came from |
| --- | --- | --- | --- | --- | --- | --- | --- |
| 650 | 2026-06-20 00:00 | 7.10 | 12.60 | 82.87E, 38.34N | 17% | 75.67E, 41.60N | NW (316 deg) |
| 650 | 2026-06-20 06:00 | 7.20 | 15.30 | 85.38E, 44.65N | 27% | 85.38E, 44.65N | NNE (17 deg) |
| 650 | 2026-06-20 12:00 | 6.80 | 25.90 | 80.04E, 40.12N | 11% | 81.92E, 40.41N | N (0 deg) |
| 650 | 2026-06-20 18:00 | 7.30 | 16.40 | 88.38E, 41.02N | 21% | 85.81E, 41.90N | NNE (30 deg) |
| 800 | 2026-06-20 00:00 | 9.20 | 18.50 | 82.58E, 39.06N | 4% | 72.05E, 39.82N | WNW (294 deg) |
| 800 | 2026-06-20 06:00 | 11.00 | 22.40 | 81.35E, 37.73N | 7% | 77.50E, 38.36N | WNW (295 deg) |
| 800 | 2026-06-20 12:00 | 11.20 | 26.70 | 79.62E, 38.73N | 0% | 82.19E, 37.59N | NNE (16 deg) |
| 800 | 2026-06-20 18:00 | 10.90 | 16.60 | 77.83E, 39.56N | 29% | 80.17E, 40.21N | NNW (338 deg) |

- 3 of 8 trajectories were in the W-WNW sector (240-330 deg) five days earlier.
- Mean fraction of the five-day path inside the 650-800 hPa high-flux layer: 15%.