# 20-day backward trajectories from the 20 June 2026 Hotan rainfall centre

Launch point: 36.84699 N, 81.91756 E (Aoyituoghelake Township, Yutian County - the reported rainfall centre of the 19-21 June 2026 event).

Met data: GDAS1 (1 deg, 3-hourly).  Runtime -480 h.  Vertical motion from the meteorology (CONTROL option 0), MSL launch heights (SETUP.CFG kmsl = 1).


## Per-trajectory summary

| level (hPa) | launch (UTC) | q at target (g/kg) | q max (g/kg) | q max location | q max level (hPa) | hours in 650-800 hPa | min p (hPa) | max height (m) | end point |
| --- | --- | --- | --- | --- | --- | --- | --- | --- | --- |
| 650 | 2026-06-20 00:00 | 7.10 | 12.60 | 82.87E, 38.34N | 865 | 144 (30%) | 465 | 6404 | -15.24E, 18.73N |
| 650 | 2026-06-20 06:00 | 7.20 | 15.30 | 85.38E, 44.65N | 914 | 76 (16%) | 398 | 7499 | 9.77E, 39.05N |
| 650 | 2026-06-20 12:00 | 6.80 | 25.90 | 80.04E, 40.12N | 888 | 36 (7%) | 314 | 9090 | 2.01E, 47.45N |
| 650 | 2026-06-20 18:00 | 7.30 | 15.50 | 88.43E, 41.16N | 884 | 59 (12%) | 253 | 10657 | -40.76E, 41.29N |
| 800 | 2026-06-20 00:00 | 9.20 | 18.20 | 82.53E, 38.94N | 882 | 5 (1%) | 143 | 14436 | 72.40E, 41.04N |
| 800 | 2026-06-20 06:00 | 11.00 | 22.40 | 81.35E, 37.73N | 868 | 120 (25%) | 427 | 6757 | 92.04E, 75.85N |
| 800 | 2026-06-20 12:00 | 11.20 | 26.70 | 79.62E, 38.73N | 878 | 48 (10%) | 280 | 9738 | 18.52E, 52.76N |
| 800 | 2026-06-20 18:00 | 10.90 | 16.60 | 77.83E, 39.56N | 860 | 38 (8%) | 316 | 9322 | -36.94E, 23.92N |

## Notes

- `q at target` is the specific humidity HYSPLIT reports at the arrival point (lead time 0), i.e. the moisture content of the air that reached the rainfall centre.

- `q max` is the moistest point along the backward path; its location is the candidate moisture-source region for that level.

- `hours in 650-800 hPa` counts hourly steps inside the layer that carries the largest per-level moisture-flux density in the 20 June sections of the manuscript's Fig. 4.


## Where the air was five days earlier (-120 h)

| level (hPa) | launch (UTC) | position 5 days back | p (hPa) | q (g/kg) | direction the air came from | % of window in 650-800 hPa |
| --- | --- | --- | --- | --- | --- | --- |
| 650 | 2026-06-20 00:00 | 75.67E, 41.60N | 497 | 2.10 | NW (316$^\circ$) | 17% |
| 650 | 2026-06-20 06:00 | 85.38E, 44.65N | 914 | 15.30 | NNE (17$^\circ$) | 28% |
| 650 | 2026-06-20 12:00 | 81.92E, 40.41N | 891 | 8.30 | N (0$^\circ$) | 11% |
| 650 | 2026-06-20 18:00 | 85.81E, 41.90N | 790 | 6.10 | NNE (30$^\circ$) | 21% |
| 800 | 2026-06-20 00:00 | 72.05E, 39.82N | 334 | 0.30 | WNW (294$^\circ$) | 4% |
| 800 | 2026-06-20 06:00 | 77.50E, 38.36N | 864 | 13.40 | WNW (295$^\circ$) | 7% |
| 800 | 2026-06-20 12:00 | 82.19E, 37.59N | 862 | 8.90 | NNE (16$^\circ$) | 0% |
| 800 | 2026-06-20 18:00 | 80.17E, 40.21N | 652 | 5.00 | NNW (338$^\circ$) | 29% |


## Consistency with the Fig. 3/4 moisture transport

- ERA5 20 June vertically integrated flux at the rainfall-centre cell: 32 kg m$^{-1}$ s$^{-1}$ toward WSW (237$^\circ$).

- ERA5 20 June area mean over the Hotan prefecture: 22 kg m$^{-1}$ s$^{-1}$ toward ESE (102$^\circ$); the prefecture is net convergent that day (+9.9 mm day$^{-1}$) and the strongest convergence sits on the piedmont just south-west of this point.

- HYSPLIT: one day before arrival, 8 of 8 parcels lay within 500 km of the centre and all eight were in the 750-900 hPa layer. Five days back, 3 of 8 parcels were west or north-west of the centre (240-330$^\circ$), 5 were north or north-east (330-90$^\circ$) and 0 came from the south or south-west (90-240$^\circ$); the five-day positions lie 86-921 km away.

- The air that arrived at 800 hPa came from along the Tarim Basin floor west and north-west of Hotan: its five-day positions span 72.0-82.2$^\circ$E and 37.6-40.2$^\circ$N, so no remote ocean is involved at this level.

- The air that arrived at 650 hPa came from over the Tianshan and the eastern Tarim margin to the north and north-east: its five-day positions span 75.7-85.8$^\circ$E and 40.4-44.6$^\circ$N, so no remote ocean is involved at this level.

- On average 15% of the first 120 hours of each trajectory stays inside the 650-800 hPa high-flux layer.

- Averaged over the whole 480 hours the in-layer fraction is 14%: the parcels leave the 650-800 hPa band quickly, which is why the first five days should be read as the transport signal and the rest of the 20-day path as background. By -480 h the parcels have scattered from the central North Atlantic to the central Pacific, so the long run carries no source information for this event.
