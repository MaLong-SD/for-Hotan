# 18-22 June 2026 Hotan moisture flux and divergence — analysis summary

ERA5 pressure-level daily-mean fields (one per day, UTC day mean); 33 x 57 grid at 0.25 deg; 23 levels 1000-200 hPa.

Study polygon: Hotan prefecture, 421 ERA5 cells intersect the boundary.
Main event day: 2026-06-20.

## Common colour-scale envelope (18-22 June 2026)

| quantity | range | unit |
| --- | --- | --- |
| vertically integrated flux magnitude | 0 - 330 | kg m-1 s-1 |
| flux divergence | +/- 160 | mm day-1 |
| section flux density | 0 - 8.5 | g cm-2 hPa-1 s-1 |
| section flux divergence | +/- 8.00e-07 | g cm-2 hPa-1 s-1 |

Same window, 99th percentile (the range actually used in the figures):

- flux magnitude 0 - 220 kg m-1 s-1
- flux divergence +/- 90 mm day-1
- section flux density 0 - 6 g cm-2 hPa-1 s-1
- section flux divergence +/- 5.0e-07 g cm-2 hPa-1 s-1

## Daily values

| day | C (mm/day) | W (mm) | max flux (kg m-1 s-1) | location | strongest convergence (mm/day) | location | share of regional area converging |
| --- | --- | --- | --- | --- | --- | --- | --- |
| 2026-06-15 | -10.85 | 29.70 | 196.1 | 86.00°E, 38.25°N | -82.2 | 75.50°E, 42.00°N | 38% |
| 2026-06-16 | -7.98 | 28.22 | 130.3 | 72.00°E, 40.50°N | -87.6 | 75.75°E, 35.50°N | 35% |
| 2026-06-17 | +2.02 | 31.12 | 119.6 | 72.25°E, 41.00°N | -108.8 | 80.50°E, 34.00°N | 58% |
| 2026-06-18 | +3.28 | 38.33 | 183.0 | 78.00°E, 38.00°N | -119.1 | 79.75°E, 35.00°N | 57% |
| 2026-06-19 | +7.55 | 41.72 | 191.9 | 85.00°E, 39.00°N | -136.7 | 80.50°E, 34.00°N | 57% |
| 2026-06-20 | +9.94 | 42.17 | 165.1 | 85.75°E, 39.00°N | -158.3 | 75.75°E, 40.25°N | 58% |
| 2026-06-21 | -3.75 | 40.75 | 186.3 | 79.00°E, 37.25°N | -139.7 | 86.00°E, 36.50°N | 45% |
| 2026-06-22 | -7.37 | 39.77 | 325.6 | 82.25°E, 37.25°N | -124.6 | 75.25°E, 39.75°N | 41% |
| 2026-06-23 | -23.34 | 35.29 | 230.3 | 86.00°E, 38.00°N | -136.2 | 86.00°E, 34.00°N | 17% |
| 2026-06-24 | -14.57 | 27.42 | 211.3 | 85.50°E, 41.50°N | -87.7 | 80.50°E, 42.00°N | 19% |
| 2026-06-25 | -5.68 | 29.37 | 237.4 | 84.75°E, 41.75°N | -90.3 | 76.00°E, 36.75°N | 41% |
| 2026-06-26 | -5.27 | 30.03 | 133.9 | 78.25°E, 40.50°N | -111.8 | 80.75°E, 34.00°N | 44% |
| 2026-06-27 | -7.71 | 30.09 | 164.6 | 74.75°E, 39.75°N | -120.9 | 80.75°E, 34.00°N | 49% |
| 2026-06-28 | -3.58 | 31.48 | 183.5 | 76.75°E, 39.00°N | -134.5 | 86.00°E, 34.00°N | 51% |
| 2026-06-29 | -13.94 | 28.06 | 167.7 | 72.00°E, 42.00°N | -127.1 | 74.75°E, 34.00°N | 40% |
| 2026-06-30 | -0.87 | 25.39 | 237.5 | 72.00°E, 40.75°N | -146.2 | 76.00°E, 41.00°N | 49% |

## Vertical sections: fixed section point

Aoyituoghelake Township, Yutian County (reported rain centre) — **81.91756 deg E, 36.84699 deg N**, the same point on every day.
Both sections are cut through that point by linear interpolation between the neighbouring ERA5 grid lines, so the section titles, the dashed marker in Fig. 4 and the white circle of Fig. 3 all name the same point. The nearest grid line (82.00 deg E, 36.75 deg N) is listed for reference only.
The daily wettest ERA5 grid cell (Fig. 2 source data) is listed for reference only and is no longer used to place the sections.

| day | regional daily max (mm/day) | section point (deg E, deg N) | nearest ERA5 cell | flux divergence (mm/day) | net convergence (mm/day) | W (mm) |
| --- | --- | --- | --- | --- | --- | --- |
| 2026-06-15 | 9.5 | 81.91756, 36.84699 | 82.00, 36.75 | +52.6 | -52.6 | 36.2 |
| 2026-06-16 | 8.2 | 81.91756, 36.84699 | 82.00, 36.75 | -9.3 | +9.3 | 28.6 |
| 2026-06-17 | 9.4 | 81.91756, 36.84699 | 82.00, 36.75 | -13.7 | +13.7 | 33.5 |
| 2026-06-18 | 16.0 | 81.91756, 36.84699 | 82.00, 36.75 | +17.4 | -17.4 | 43.7 |
| 2026-06-19 | 28.5 | 81.91756, 36.84699 | 82.00, 36.75 | +7.9 | -7.9 | 51.8 |
| 2026-06-20 | 61.2 | 81.91756, 36.84699 | 82.00, 36.75 | -5.2 | +5.2 | 52.0 |
| 2026-06-21 | 23.1 | 81.91756, 36.84699 | 82.00, 36.75 | +39.8 | -39.8 | 47.6 |
| 2026-06-22 | 14.9 | 81.91756, 36.84699 | 82.00, 36.75 | +45.6 | -45.6 | 46.9 |
| 2026-06-23 | 17.5 | 81.91756, 36.84699 | 82.00, 36.75 | +38.8 | -38.8 | 41.5 |
| 2026-06-24 | 2.7 | 81.91756, 36.84699 | 82.00, 36.75 | +11.9 | -11.9 | 29.5 |
| 2026-06-25 | 3.2 | 81.91756, 36.84699 | 82.00, 36.75 | -1.9 | +1.9 | 33.2 |
| 2026-06-26 | 3.6 | 81.91756, 36.84699 | 82.00, 36.75 | +4.7 | -4.7 | 34.9 |
| 2026-06-27 | 6.6 | 81.91756, 36.84699 | 82.00, 36.75 | -14.1 | +14.1 | 32.3 |
| 2026-06-28 | 9.0 | 81.91756, 36.84699 | 82.00, 36.75 | -10.7 | +10.7 | 36.1 |
| 2026-06-29 | 5.0 | 81.91756, 36.84699 | 82.00, 36.75 | -6.2 | +6.2 | 31.1 |
| 2026-06-30 | 0.9 | 81.91756, 36.84699 | 82.00, 36.75 | -41.6 | +41.6 | 23.3 |

## Vertical sections through the rain centre

| day | section pair | max section flux density (g cm-2 hPa-1 s-1) | max |section divergence| (g cm-2 hPa-1 s-1) |
| --- | --- | --- | --- |
| 2026-06-15 | 36.85N / 81.92E | 4.22 | 6.32e-07 |
| 2026-06-16 | 36.85N / 81.92E | 2.91 | 3.25e-07 |
| 2026-06-17 | 36.85N / 81.92E | 4.00 | 3.88e-07 |
| 2026-06-18 | 36.85N / 81.92E | 4.93 | 7.44e-07 |
| 2026-06-19 | 36.85N / 81.92E | 6.58 | 6.82e-07 |
| 2026-06-20 | 36.85N / 81.92E | 6.46 | 5.39e-07 |
| 2026-06-21 | 36.85N / 81.92E | 6.75 | 5.65e-07 |
| 2026-06-22 | 36.85N / 81.92E | 8.35 | 6.15e-07 |
| 2026-06-23 | 36.85N / 81.92E | 6.00 | 5.38e-07 |
| 2026-06-24 | 36.85N / 81.92E | 6.28 | 4.27e-07 |
| 2026-06-25 | 36.85N / 81.92E | 5.17 | 3.23e-07 |
| 2026-06-26 | 36.85N / 81.92E | 2.94 | 3.63e-07 |
| 2026-06-27 | 36.85N / 81.92E | 4.25 | 4.25e-07 |
| 2026-06-28 | 36.85N / 81.92E | 4.18 | 3.68e-07 |
| 2026-06-29 | 36.85N / 81.92E | 3.80 | 3.65e-07 |
| 2026-06-30 | 36.85N / 81.92E | 5.42 | 4.70e-07 |

## Regional extremes and mean transport (421 cells over Hotan)

Two regional means are listed: the area-weighted mean of the per-cell flux magnitude, and the weaker magnitude of the area-mean transport vector, whose value is reduced by directional cancellation within the region.

| day | mean flux magnitude (kg m-1 s-1) | |mean transport vector| (kg m-1 s-1) | transport toward | came from | max flux in region (kg m-1 s-1) | location | strongest convergence in region (mm/day) | location |
| --- | --- | --- | --- | --- | --- | --- | --- | --- |
| 2026-06-15 | 47.6 | 17.4 | SSW | NNE | 150.7 | 84.00°E, 37.75°N | -80.3 | 83.75°E, 35.75°N |
| 2026-06-16 | 26.7 | 9.1 | SSE | NNW | 87.2 | 84.00°E, 36.00°N | -46.7 | 81.25°E, 36.75°N |
| 2026-06-17 | 33.3 | 5.6 | NW | SE | 104.0 | 78.50°E, 37.50°N | -61.9 | 83.25°E, 37.25°N |
| 2026-06-18 | 47.8 | 19.1 | WNW | ESE | 183.0 | 78.00°E, 38.00°N | -95.7 | 80.25°E, 37.50°N |
| 2026-06-19 | 41.7 | 23.7 | ESE | WNW | 145.1 | 83.75°E, 38.25°N | -92.3 | 80.75°E, 36.00°N |
| 2026-06-20 | 44.6 | 22.1 | ESE | WNW | 111.0 | 79.00°E, 37.25°N | -107.6 | 81.75°E, 36.25°N |
| 2026-06-21 | 77.9 | 35.4 | E | W | 186.3 | 79.00°E, 37.25°N | -59.0 | 80.75°E, 36.25°N |
| 2026-06-22 | 126.8 | 112.6 | E | W | 325.6 | 82.25°E, 37.25°N | -47.1 | 83.50°E, 38.75°N |
| 2026-06-23 | 63.5 | 43.1 | ESE | WNW | 222.2 | 84.00°E, 37.25°N | -43.2 | 83.75°E, 35.75°N |
| 2026-06-24 | 51.9 | 28.7 | WNW | ESE | 115.0 | 83.75°E, 38.25°N | -40.5 | 81.25°E, 36.75°N |
| 2026-06-25 | 26.5 | 12.0 | ENE | WSW | 70.7 | 84.75°E, 35.50°N | -60.1 | 82.75°E, 37.25°N |
| 2026-06-26 | 26.2 | 3.5 | SSE | NNW | 73.0 | 85.00°E, 35.75°N | -54.7 | 83.00°E, 37.25°N |
| 2026-06-27 | 46.7 | 34.4 | ESE | WNW | 115.5 | 79.75°E, 39.50°N | -63.2 | 81.25°E, 36.75°N |
| 2026-06-28 | 58.1 | 47.7 | ESE | WNW | 124.9 | 78.25°E, 38.25°N | -86.5 | 83.50°E, 37.25°N |
| 2026-06-29 | 39.8 | 24.6 | ESE | WNW | 122.5 | 84.50°E, 36.00°N | -56.8 | 81.25°E, 36.75°N |
| 2026-06-30 | 62.9 | 56.1 | WNW | ESE | 127.0 | 80.25°E, 39.25°N | -71.2 | 81.25°E, 36.75°N |
